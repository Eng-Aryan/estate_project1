/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.util.ArrayList;

/**
 *
 * @author RTX
 */
public class estate {
   
    private ArrayList<property> properties;
    private final int max_properties = 100;

    public estate() {
        
         properties = new ArrayList<>();
         
    }
    
     public boolean addProperty(property Property) {
        if (properties.size() < max_properties) {
            properties.add(Property);
            return true;
        } else {
            System.out.println("Cannot add property");
            return false;
        }
    }
     
      public boolean removeProperty(property Property) {
        return properties.remove(Property);
    }

    public void listProperties() {
        if (properties.isEmpty()) {
            System.out.println("No available.");
        } else {
            for (property Property : properties) {
                Property.display();
                System.out.println("----------------------------------------------------------------------------------\n\n");
            }
        }
    }
}
