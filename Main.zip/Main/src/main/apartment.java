/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author RTX
 */
public class apartment extends property{
     private int floor;
    private boolean parkinglot;

    public apartment(int floor, boolean parkinglot, double area, int n_Rooms, String neighborName, double price) {
        super(area, n_Rooms, neighborName, price);
        this.floor = floor;
        this.parkinglot = parkinglot;
    }
    
       @Override
    public void display() {
        super.display();
        System.out.println("Type: Apartment");
        System.out.println("Floor: " + floor);
       if (parkinglot) {
    System.out.println("Has Parking Lot:Yes");
} else {
    System.out.println("Has Parking Lot:No");
}
    }

    
    
}
