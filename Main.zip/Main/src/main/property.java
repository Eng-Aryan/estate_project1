/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author RTX
 */
public class property {
  private  double area ;
  private int n_Rooms;
  private String neighborName;
  private double price;

    public property(double area, int n_Rooms, String neighborName, double price) {
        this.area = area;
        this.n_Rooms = n_Rooms;
        this.neighborName = neighborName;
        this.price = price;
    }

    public double getArea() {
        return area;
    }

    public int getN_Rooms() {
        return n_Rooms;
    }

    public String getNeighborName() {
        return neighborName;
    }

    public double getPrice() {
        return price;
    }
    
    
    
      public void display() {
        System.out.println("Property:");
        System.out.println("Area: " + area);
        System.out.println("Number of Rooms: " + n_Rooms);
        System.out.println("Neighborhood: " + neighborName);
        System.out.println("Price: $" + price);
    }

    
    
    
    
    
}
