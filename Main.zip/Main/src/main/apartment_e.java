/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author RTX
 */
public class apartment_e extends apartment{
     private int Quality;

    public apartment_e(int Quality, int floor, boolean parkinglot, double area, int n_Rooms, String neighborName, double price) {
        super(floor, parkinglot, area, n_Rooms, neighborName, price);
        this.Quality = Quality;
    }
     @Override
    public void display() {
        super.display();
        System.out.println("Furniture Quality: " +Quality + "1=verygood, 5=bad");
    }
     
     
     
}
