/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author RTX
 */
public class vella extends property {
     private boolean swimmingPool;
    private int n_adjacentStreets;

    public vella(boolean swimmingPool, int n_adjacentStreets, double area, int n_Rooms, String neighborName, double price) {
        super(area, n_Rooms, neighborName, price);
        this.swimmingPool = swimmingPool;
        this.n_adjacentStreets = n_adjacentStreets;
    }
      @Override
    public void display() {
        super.display();
        System.out.println("Type: Villa");
       if (swimmingPool) {
    System.out.println("Has Swimming Pool: Yes");
} else {
    System.out.println("Has Swimming Pool: No");
}
        System.out.println("Number of Adjacent Streets: " + n_adjacentStreets);
    }
    
    
    
    
    
}
