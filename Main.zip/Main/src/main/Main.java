
package main;


public class Main {

    
    public static void main(String[] args) {

         estate agency = new estate();
        vella v = new vella(true, 3,500, 10,"Rako" , 3000);
        apartment ap = new apartment(2, true, 150, 5, "bavin", 2000);
        apartment_e furnishedApartment = new apartment_e(3,3,true,150,6,"ahmad",2500 );

         agency.addProperty(v);
        agency.addProperty(ap);
        agency.addProperty(furnishedApartment);
          agency.listProperties();
          agency.removeProperty(ap);
        System.out.println("After removal:");
        agency.listProperties();
    }
    
}
